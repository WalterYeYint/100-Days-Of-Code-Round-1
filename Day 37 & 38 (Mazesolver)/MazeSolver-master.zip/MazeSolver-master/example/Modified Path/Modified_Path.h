#ifndef __MODIFIED_PATH_INCLUDES__
#define __MODIFIED_PATH_INCLUDES__

#include "Path.h"
#include "DepthFirstSearch.h"
#include "BreadthFirstSearch.h"
#include "Dijkstra.h"
#include  "AStar.h"


#endif // !__PATH__
